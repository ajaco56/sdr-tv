#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2021, IBM ABN-AMRO

from __future__ import absolute_import, division, print_function
__metaclass__ = type

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['wip'],
                    'supported_by': 'IBM/ABN-AMRO ansbile team'}
DOCUMENTATION = r'''
---
module: manageservers
short_description: Start or Stop all JVM's on the node
description:
- Provide a wrapper arround the (c) Websphere application shell scripts. 
  There are several steps/scripts combined to determin the server, the state of these servers and the control of start/stop of the servers. 
  The start/stop is nowaited to mantain control with ansible when a JVM can't reached the requested state.
options:
  server_state:
    description: The desired state the servers should be in.
    required: true
    type: str
    choices: [ stopped, started ]
  params:
    description: all or specific jvm
    required: true
  max_count:
    description: Specify the number of retries to wait for the server to reach the correct state
    default: 10
    type: int
    required: false
  monitor_wait_time:
    description: Specify the number of seconds between the check samples
    default: 10
    type: int
    required: false
  wait_after_action:
    description: Specify the number of seconds to wait after initating the start/stop, before starting the monitoring
    default: 15
    type: int
    required: false
  fail_after_max_count:
    description: Is exceeding the max count an error or a warning
    default: true
    type: bool
    required: false
  wasdir:
    description:
    - The rout path of the Websphere installation.
    type: path
    default: /appl/was
  nowait:
    description:
    - Option to skill waiting on the start of the server to finish. 
    type: bool
    default: False

notes:
-  None.

version_added: 0.0.1
author:
- Joined IBM and ABN-AMRO infra ansible team
'''

EXAMPLES = r'''
# start all servers, but continue when one or more JVM are not started compleedly 
- name: start of all servers without fail
  manageservers:
     server_state: "started"
     params: "all"
     fail_after_max_count: False
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo
# start all servers, but fail when one or more JVM are not started compleedly 
- name: start of all servers with fail
  manageservers:
     server_state: "started"
     params: "all"
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo
    - debug:
        msg: "{{ rc }}"
'''

RETURN = r''' 
rc:
  description: script return code.
  returned: always
  type: int
  sample: 0
stdout:
  description: raw output written to the stdout by the script executed
  returned: always
  type: str
  sample: this ouput is multiline\\nyou see
stdout_lines:
  description: raw output written to the stdout by the script executed, converted into string array by \\n delimiter
  returned: always
  type: str
  sample: 
     - this ouput is multiline
     - you see
stderr:
  description: raw output written to the stderr by the script executed
  returned: always
  type: str
  sample: this ouput is multiline\nyou see
stderr_lines:
  description: raw output written to the stderr by the script executed, converted into string array by \n delimiter
  returned: always
  type: str
  sample: 
     - this ouput is multiline
     - you see
'''
from sys import stderr, stdout
from ansible.module_utils.websphere.websphere_common import StopServer, StartServer
from ansible.module_utils.websphere.server_status_action import ServerActions, ServerInfo

def main():
    # Read arguments
    module = AnsibleModule(
        argument_spec=dict(
            server_state=dict(required=True, type='str',
                              choices=['stopped', 'started']),
            params=dict(required=True),
            wasdir=dict(default='/appl/was', type='path', required=False),
            max_count=dict(default=10, type='int', required=False),
            monitor_wait_time=dict(default=10, type='int', required=False),
            wait_after_action=dict(default=15, type='int', required=False),
            fail_after_max_count=dict(
                default=True, type='bool', required=False)
        )
    )
    server_state = (module.params['server_state']).upper()
    params = module.params['params']
    wasdir = module.params['wasdir']
    max_count = module.params['max_count']
    monitor_wait_time = module.params['monitor_wait_time']
    wait_after_action = module.params['wait_after_action']
    fail_after_max_count = module.params['fail_after_max_count']
#    if not (server_state == ServerInfo.state_stopped or server_state == ServerInfo.state_started):
#        module.fail_json(msg=["Invalid parameters", "server_state is " + server_state + " and should be " + ServerStatus.state_stopped + " or " + ServerStatus.state_started
#                              ], stdout=None, stderr=None)
    # fetch all servers known by the Cell via serverStatus.sh, and log their current state
    serv_stat_all = ServerActions(wasdir, "-all", server_state)
    serv_stat_all.execute()
    if serv_stat_all.get_returncode() != 0:
        module.fail_json(msg=["Executing serverStatus.sh failed", "process arg: " + serv_stat_all.get_processagruments(),
                              "stdin: " + serv_stat_all.getstdinlog()], stdout=serv_stat_all.get_stdout(), stderr=serv_stat_all.get_stderr())

    serv_stat_all.parse()
    module.warn("instances" + serv_stat_all.to_json_str())
    # loop through the found servers and stop or start the server when the state is
    # okay was servers can also return 246... indicating server can't be reached
    all_processed = serv_stat_all.do_appl_servers_processor()
    for result in all_processed:
        if not result.is_non_fatal_rc():
            module.fail_json(msg=["Executing stop or start failed", "process arg: " + result.get_processagruments(), "Return code: " + str(result.get_returncode()),
                                  "stdin: " + result.getstdinlog()], stdout=result.get_stdout(), stderr=result.get_stderr())
        module.warn("Object " + result.get_processagruments() +
                    ",rc: " + str(result.get_returncode()))

    # allow time for the initation of the action to be commanced
    time.sleep(wait_after_action)
    all_processed = serv_stat_all.do_appl_servers_monitor()
    action_failed = False
    while True:
        all_requested_state = True
        max_count_reached = True
        for result in all_processed:
            monitor = result.get_monitor()
            if not monitor.is_non_fatal_rc():
                module.fail_json(msg=["Executing monitoring failed", "process arg: " + monitor.get_processagruments(), "Return code: " + str(monitor.get_returncode()),
                                      "stdin: " + monitor.getstdinlog()], stdout=monitor.get_stdout(), stderr=monitor.get_stderr())
            if result.get_count < max_count:
                max_count_reached = False
            if result.is_in_requested_state():
                module.warn("Success Object " + result.to_json_str())
            else:
                all_requested_state = False
                module.warn("Wainting Object " + result.to_json_str())
        if all_requested_state or max_count_reached:
            action_failed = True
            break
        # Wait between the monitor actions.. No use to check every second
        time.sleep(monitor_wait_time)
    if action_failed and fail_after_max_count:
        module.fail_json(msg=["Executing manage failed"], action_failed=action_failed, fail_after_max_count=fail_after_max_count,
                         stdout=serv_stat_all.to_json_str(), stderr=None)
    module.exit_json(changed=True, msg=[
                     "Executing manage successfully"], action_failed=action_failed, fail_after_max_count=fail_after_max_count, stdout=serv_stat_all.to_json_str(), stderr=None)


if __name__ == '__main__':
    main()
