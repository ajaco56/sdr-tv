#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2021, IBM ABN-AMRO

from __future__ import absolute_import, division, print_function
__metaclass__ = type

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['wip'],
                    'supported_by': 'IBM/ABN-AMRO ansbile team'}
DOCUMENTATION = r'''
---
module: wsadmin
short_description: Invoke the websphere stop server script (stopServer.sh)
short_description: Invoke the websphere start server script (startServer.sh)
description:
- Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output
options:
  params:
    description:
    - Random option to pass to the wsadmin.sh
    type: str
    required: false
  wasdir:
    description:
    - The rout path of the Websphere installation.
    type: path
    default: /appl/was/profiles/dmgr
  script_stdin:
    description:
    - String to be passed to the stdin of the executing wsadmin.sh
    type: str
    default: None
  script_file:
    description:
    - file that will be processed with the -f to the executing wsadmin.sh
    type: path
    default: None

notes:
-  None.

version_added: 0.0.1
author:
- Joined IBM and ABN-AMRO infra ansible team
'''

EXAMPLES = r'''
# only string as input
- name: Passing string to wsadmin
  wsadmin:
     script_stdin: print 'Hello world, whats the meaning of life'
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo
# only file as input
- name: passing file to wsadmin
  wsadmin:
     script_file: /tmp/ansible/test
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo  
# string and file as input
- name: passing both a file and string to wsadmin
  wsadmin:
     script_stdin: print 'Hello world, whats the meaning of life'
     script_file: /tmp/ansible/test
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo  
'''

RETURN = r''' 
rc:
  description: script return code.
  returned: always
  type: int
  sample: 0
stdout:
  description: filtered output written to the stdout by the script executed. Message starting with one of these WASX7023E,WASX7213I,WASX8011W,WASX7031I are removed
  returned: always
  type: str
  sample: this ouput is multiline\nyou see
stdout_lines:
  description: filtered output written to the stdout by the script executed, converted into string array by \n delimiter
  returned: always
  type: str
  sample: 
     - this ouput is multiline
     - you see
stderr:
  description: raw output written to the stderr by the script executed
  returned: always
  type: str
  sample: this ouput is multiline\nyou see
stderr_lines:
  description: raw output written to the stderr by the script executed, converted into string array by \n delimiter
  returned: always
  type: str
  sample: 
     - this ouput is multiline
     - you see
'''
from ansible.module_utils.websphere.websphere_common import WSAdmin
from ansible.module_utils.basic import AnsibleModule


def main():
    # Read arguments
    module = AnsibleModule(
        argument_spec=dict(
            params=dict(default=None, required=False, type='str'),
            wasdir=dict(default='/appl/was/',
                        required=False, type='path'),
            script_stdin=dict(default=None, required=False, type='str'),
            script_file=dict(default=None, required=False, type='path')
        )
    )

    params = module.params['params']
    wasdir = module.params['wasdir']
    script_stdin = module.params['script_stdin']
    script_file = module.params['script_file']
    shell_process = WSAdmin(wasdir, params, script_stdin, script_file)
    shell_process.execute()

    if shell_process.get_returncode() != 0:
        module.fail_json(msg=["Executing wsadmin failed", "script: " + shell_process.getfilelog()], stdin=shell_process.getstdinlog(),
                         rc=shell_process.get_returncode(), stdout=shell_process.get_stdout(), stderr=shell_process.get_stderr())
    module.exit_json(changed=True, msg=["Executing wsadmin successfully", "script: " + shell_process.getfilelog()], stdin=shell_process.getstdinlog(
    ), rc=shell_process.get_returncode(), stdout=shell_process.get_stdout(), stderr=shell_process.get_stderr())


if __name__ == '__main__':
    main()
