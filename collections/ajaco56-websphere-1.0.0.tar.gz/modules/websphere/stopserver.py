#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2021, IBM ABN-AMRO

from __future__ import absolute_import, division, print_function
__metaclass__ = type

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['wip'],
                    'supported_by': 'IBM/ABN-AMRO ansbile team'}
DOCUMENTATION = r'''
---
module: stopserver
short_description: Invoke the websphere stop server script (stopServer.sh)
description:
- Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output
options:
  params:
    description:
    - The Websphere Application Server to be started.
    type: str
    required: true
  wasdir:
    description:
    - The rout path of the Websphere installation.
    type: path
    default: /appl/was
  nowait:
    description:
    - Option to skill waiting on the start of the server to finish. 
    type: bool
    default: False

notes:
-  None.

version_added: 0.0.1
author:
- Joined IBM and ABN-AMRO infra ansible team
'''

EXAMPLES = r'''
# stop a JVM in nowaited mode
- name: Stop the JVM <stc1xxx> nowait 
  stopserver:
     params: "{{ servername }}"
     nowait: True
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo
# stop a JVM in waited mode
- name: Stop the JVM <stc1xxx> waited
  stoserver:
     params: "{{ servername }}"
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo
  debug:
    msg: "{{ rc }}"
  
'''

RETURN = r''' 
rc:
  description: script return code.
  returned: always
  type: int
  sample: 0
stdout:
  description: raw output written to the stdout by the script executed
  returned: always
  type: str
  sample: this ouput is multiline\nyou see
stdout_lines:
  description: raw output written to the stdout by the script executed, converted into string array by \n delimiter
  returned: always
  type: str
  sample: 
     - this ouput is multiline
     - you see
stderr:
  description: raw output written to the stderr by the script executed
  returned: always
  type: str
  sample: this ouput is multiline\nyou see
stderr_lines:
  description: raw output written to the stderr by the script executed, converted into string array by \n delimiter
  returned: always
  type: str
  sample: 
     - this ouput is multiline
     - you see
'''

from ansible.module_utils.websphere.websphere_common import StopServer
from ansible.module_utils.basic import AnsibleModule
def main():

    # Read arguments
    module = AnsibleModule(
        argument_spec=dict(
            params=dict(required=True, type='str'),
            wasdir=dict(default='/appl/was', required=False, type='path'),
            nowait=dict(default=False, required=False, type='bool'),
            timeout=dict(default=300, required=False, type='int')
        )
    )

    params = module.params['params']
    wasdir = module.params['wasdir']
    nowait = module.params['nowait']
    timeout = module.params['timeout']

    shell_process = StopServer(wasdir, params, nowait, timeout)
    shell_process.execute()
    if shell_process.get_returncode() != 0:
        proccessed_results = shell_process.to_json()
        module.fail_json(msg=["Executing serverStop.sh failed", "process arg: " + shell_process.get_processagruments()],process_results=proccessed_results,
                         stdin=shell_process.getstdinlog(), stdout=shell_process.get_stdout(), stderr=shell_process.get_stderr())
    proccessed_results = shell_process.to_json()
    module.exit_json(changed=True, msg=["Executing wsadmin successfully", "process arg: "+ shell_process.get_processagruments()],process_results=proccessed_results,
                         stdin=shell_process.getstdinlog(), stdout=shell_process.get_stdout(), stderr=shell_process.get_stderr())


# import module snippets
if __name__ == '__main__':
    main()
