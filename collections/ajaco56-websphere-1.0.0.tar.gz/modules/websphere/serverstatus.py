#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2021, IBM ABN-AMRO

from __future__ import absolute_import, division, print_function

__metaclass__ = type

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['wip'],
                    'supported_by': 'IBM/ABN-AMRO ansbile team'}
DOCUMENTATION = r'''
---
module: serverstatus
short_description: Invoke the websphere server status script (serverStatus.sh)
description:
- Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output. Only lines starting with ADMU0508I or ADMU0509I will be returned.
options:
  params:
    description:
    - The Websphere Application Server to be stated of -all to state all servers
    type: str
    required: true
  wasdir:
    description:
    - The rout path of the Websphere installation.
    type: path
    default: /appl/was

notes:
-  None.

version_added: 0.0.1
author:
- Joined IBM and ABN-AMRO infra ansible team
'''

EXAMPLES = r'''
# status of all servers
- name: status of all servers 
  serverstatus:
     params: "-all"
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo
# status of all servers
- name: status of one server
  serverstatus:
     params: stc1xxx
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo
  
'''

RETURN = r''' 
process_results:
  description: parsed results from the process in JSON fromat.
  returned: always
  type: str
  sample: {'Web server': {'sth1bve': {'state': 'STOPPED'}}, 'Application Server': {'stc1bve': {'state': 'UNREACHABLE'}}, 'Node Agent': {'nodeagent': {'state': 'UNREACHABLE'}}, 'rc': None}
stdout:
  description: filtered output written to the stdout by the script executed
  returned: always
  type: str
  sample: this ouput is multiline\nyou see
stdout_lines:
  description: filted output written to the stdout by the script executed, converted into string array by \n delimiter
  returned: always
  type: str
  sample: 
     - this ouput is multiline
     - you see
stderr:
  description: raw output written to the stderr by the script executed
  returned: always
  type: str
  sample: this ouput is multiline\nyou see
stderr_lines:
  description: raw output written to the stderr by the script executed, converted into string array by \n delimiter
  returned: always
  type: str
  sample: 
     - this ouput is multiline
     - you see
'''
from ansible.module_utils.basic import *
from ansible.module_utils.websphere.server_status import ServerStatus

def main():
    # Read arguments
    module = AnsibleModule(
        argument_spec=dict(
            params=dict(required=True, type='str'),
            wasdir=dict(default='/appl/was', required=False, type='path')
        )
    )

    params = module.params['params']
    wasdir = module.params['wasdir']
    shell_process = ServerStatus(wasdir, params)
    shell_process.execute()

    if shell_process.get_returncode() != 0:
        proccessed_results = shell_process.to_json()
        module.fail_json(msg=["Executing serverStatus.sh failed", "process arg: " + shell_process.get_processagruments()], process_results=proccessed_results,
                         stdin=shell_process.getstdinlog(), stdout=shell_process.get_stdout(), stderr=shell_process.get_stderr())
    shell_process.process_result()
    proccessed_results = shell_process.to_json()

    module.exit_json(changed=True, msg=["Executing wsadmin successfully", "process arg: " + shell_process.get_processagruments(
    )], process_results=proccessed_results, stdin=shell_process.getstdinlog(),  stdout=shell_process.get_stdout(), stderr=shell_process.get_stderr())


if __name__ == '__main__':
    main()
