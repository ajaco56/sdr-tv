.. _wsadmin_module:


wsadmin -- Invoke the websphere start server script (startServer.sh)
====================================================================

.. contents::
   :local:
   :depth: 1
   :backlinks: top

Synopsis
--------

Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output






Parameters
----------

 params
   (
   Required: False,
   Type:     str
   )

   Description:
     Random option to pass to the wsadmin.sh


 wasdir
   (
   Required: optional,
   Type:     path,
   Default:  /appl/was/profiles/dmgr
   )

   Description:
     The rout path of the Websphere installation.


 script_stdin
   (
   Required: optional,
   Type:     str
   )

   Description:
     String to be passed to the stdin of the executing wsadmin.sh


 script_file
   (
   Required: optional,
   Type:     path
   )

   Description:
     file that will be processed with the -f to the executing wsadmin.sh





Notes
-----

.. note::
   - None.




Examples
--------

.. code-block:: yaml+jinja 

    
    # only string as input
    - name: Passing string to wsadmin
      wsadmin:
         script_stdin: print 'Hello world, whats the meaning of life'
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
    # only file as input
    - name: passing file to wsadmin
      wsadmin:
         script_file: /tmp/ansible/test
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo  
    # string and file as input
    - name: passing both a file and string to wsadmin
      wsadmin:
         script_stdin: print 'Hello world, whats the meaning of life'
         script_file: /tmp/ansible/test
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo  



Return Values
-------------

rc 
  ( 
  Returned: always,
  Type:     int,
  Sample:   0
  )
Description:
  script return code.


stdout 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  filtered output written to the stdout by the script executed. Message starting with one of these WASX7023E,WASX7213I,WASX8011W,WASX7031I are removed


stdout_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  filtered output written to the stdout by the script executed, converted into string array by \n delimiter


stderr 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stderr by the script executed


stderr_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stderr by the script executed, converted into string array by \n delimiter





Status
------




- This module is . *[wip]*


- This module is maintained by IBM/ABN-AMRO ansbile team.



Authors
~~~~~~~

- Joined IBM and ABN-AMRO infra ansible team

