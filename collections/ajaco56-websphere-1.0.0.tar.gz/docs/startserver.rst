.. _startserver_module:


startserver -- Invoke the websphere start server script (startServer.sh)
========================================================================

.. contents::
   :local:
   :depth: 1
   :backlinks: top

Synopsis
--------

Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output






Parameters
----------

 params
   (
   Required: True,
   Type:     str
   )

   Description:
     The Websphere Application Server to be started.


 wasdir
   (
   Required: optional,
   Type:     path,
   Default:  /appl/was
   )

   Description:
     The rout path of the Websphere installation.


 nowait
   (
   Required: optional,
   Type:     bool,
   Default:  False
   )

   Description:
     Option to skill waiting on the start of the server to finish.





Notes
-----

.. note::
   - None.




Examples
--------

.. code-block:: yaml+jinja 

    
    # start a JVM in nowaited mode
    - name: Start the JVM <stc1xxx> nowait 
      startserver:
         params: "{{ servername }}"
         nowait: True
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
    # start a JVM in waited mode
    - name: Start the JVM <stc1xxx> waited
      startserver:
         params: "{{ servername }}"
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
      debug:
        msg: "{{ rc }}"
      



Return Values
-------------

rc 
  ( 
  Returned: always,
  Type:     int,
  Sample:   0
  )
Description:
  script return code.


stdout 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stdout by the script executed


stdout_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stdout by the script executed, converted into string array by \n delimiter


stderr 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stderr by the script executed


stderr_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stderr by the script executed, converted into string array by \n delimiter





Status
------




- This module is . *[wip]*


- This module is maintained by IBM/ABN-AMRO ansbile team.



Authors
~~~~~~~

- Joined IBM and ABN-AMRO infra ansible team

