.. _serverstatus_module:


serverstatus -- Invoke the websphere server status script (serverStatus.sh)
===========================================================================

.. contents::
   :local:
   :depth: 1
   :backlinks: top

Synopsis
--------

Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output. Only lines starting with ADMU0508I or ADMU0509I will be returned.






Parameters
----------

 params
   (
   Required: True,
   Type:     str
   )

   Description:
     The Websphere Application Server to be stated of -all to state all servers


 wasdir
   (
   Required: optional,
   Type:     path,
   Default:  /appl/was
   )

   Description:
     The rout path of the Websphere installation.





Notes
-----

.. note::
   - None.




Examples
--------

.. code-block:: yaml+jinja 

    
    # status of all servers
    - name: status of all servers 
      serverstatus:
         params: "-all"
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
    # status of all servers
    - name: status of one server
      serverstatus:
         params: stc1xxx
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
      



Return Values
-------------

process_results 
  ( 
  Returned: always,
  Type:     str,
  Sample:   {'Web server': {'sth1bve': {'state': 'STOPPED'}}, 'Application Server': {'stc1bve': {'state': 'UNREACHABLE'}}, 'Node Agent': {'nodeagent': {'state': 'UNREACHABLE'}}, 'rc': 'None'}
  )
Description:
  parsed results from the process in JSON fromat.


stdout 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  filtered output written to the stdout by the script executed


stdout_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  filted output written to the stdout by the script executed, converted into string array by \n delimiter


stderr 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stderr by the script executed


stderr_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stderr by the script executed, converted into string array by \n delimiter





Status
------




- This module is . *[wip]*


- This module is maintained by IBM/ABN-AMRO ansbile team.



Authors
~~~~~~~

- Joined IBM and ABN-AMRO infra ansible team

