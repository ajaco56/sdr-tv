.. _README:

README
======

Include the generated modules files

.. contents::
   :depth: 1
   :backlinks: top

Modules
========





.. _manageservers_module:


manageservers -- Start or Stop all JVM's on the node
====================================================

.. contents::
   :local:
   :depth: 1
   :backlinks: top

Synopsis
--------

Provide a wrapper arround the (c) Websphere application shell scripts. There are several steps/scripts combined to determin the server, the state of these servers and the control of start/stop of the servers. The start/stop is nowaited to mantain control with ansible when a JVM can't reached the requested state.






Parameters
----------

 server_state
   (
   Required: True,
   Type:     str,
   Choices:  ['stopped', 'started']
   )

   Description:
     The desired state the servers should be in.


 params
   (
   Required: True,
   Type:     any
   )

   Description:
     all or specific jvm


 max_count
   (
   Required: False,
   Type:     int,
   Default:  10
   )

   Description:
     Specify the number of retries to wait for the server to reach the correct state


 monitor_wait_time
   (
   Required: False,
   Type:     int,
   Default:  10
   )

   Description:
     Specify the number of seconds between the check samples


 wait_after_action
   (
   Required: False,
   Type:     int,
   Default:  15
   )

   Description:
     Specify the number of seconds to wait after initating the start/stop, before starting the monitoring


 fail_after_max_count
   (
   Required: False,
   Type:     bool,
   Default:  True
   )

   Description:
     Is exceeding the max count an error or a warning


 wasdir
   (
   Required: optional,
   Type:     path,
   Default:  /appl/was
   )

   Description:
     The rout path of the Websphere installation.


 nowait
   (
   Required: optional,
   Type:     bool,
   Default:  False
   )

   Description:
     Option to skill waiting on the start of the server to finish.





Notes
-----

.. note::
   - None.




Examples
--------

.. code-block:: yaml+jinja 

    
    # start all servers, but continue when one or more JVM are not started compleedly 
    - name: start of all servers without fail
      manageservers:
         server_state: "started"
         params: "all"
         fail_after_max_count: False
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
    # start all servers, but fail when one or more JVM are not started compleedly 
    - name: start of all servers with fail
      manageservers:
         server_state: "started"
         params: "all"
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
        - debug:
            msg: "{{ rc }}"



Return Values
-------------

rc 
  ( 
  Returned: always,
  Type:     int,
  Sample:   0
  )
Description:
  script return code.


stdout 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\\nyou see
  )
Description:
  raw output written to the stdout by the script executed


stdout_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stdout by the script executed, converted into string array by \\n delimiter


stderr 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stderr by the script executed


stderr_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stderr by the script executed, converted into string array by \n delimiter





Status
------




- This module is . *[wip]*


- This module is maintained by IBM/ABN-AMRO ansbile team.



Authors
~~~~~~~

- Joined IBM and ABN-AMRO infra ansible team

.. _serverstatus_module:


serverstatus -- Invoke the websphere server status script (serverStatus.sh)
===========================================================================

.. contents::
   :local:
   :depth: 1
   :backlinks: top

Synopsis
--------

Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output. Only lines starting with ADMU0508I or ADMU0509I will be returned.






Parameters
----------

 params
   (
   Required: True,
   Type:     str
   )

   Description:
     The Websphere Application Server to be stated of -all to state all servers


 wasdir
   (
   Required: optional,
   Type:     path,
   Default:  /appl/was
   )

   Description:
     The rout path of the Websphere installation.





Notes
-----

.. note::
   - None.




Examples
--------

.. code-block:: yaml+jinja 

    
    # status of all servers
    - name: status of all servers 
      serverstatus:
         params: "-all"
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
    # status of all servers
    - name: status of one server
      serverstatus:
         params: stc1xxx
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
      



Return Values
-------------

process_results 
  ( 
  Returned: always,
  Type:     str,
  Sample:   {'Web server': {'sth1bve': {'state': 'STOPPED'}}, 'Application Server': {'stc1bve': {'state': 'UNREACHABLE'}}, 'Node Agent': {'nodeagent': {'state': 'UNREACHABLE'}}, 'rc': 'None'}
  )
Description:
  parsed results from the process in JSON fromat.


stdout 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  filtered output written to the stdout by the script executed


stdout_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  filted output written to the stdout by the script executed, converted into string array by \n delimiter


stderr 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stderr by the script executed


stderr_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stderr by the script executed, converted into string array by \n delimiter





Status
------




- This module is . *[wip]*


- This module is maintained by IBM/ABN-AMRO ansbile team.



Authors
~~~~~~~

- Joined IBM and ABN-AMRO infra ansible team

.. _startserver_module:


startserver -- Invoke the websphere start server script (startServer.sh)
========================================================================

.. contents::
   :local:
   :depth: 1
   :backlinks: top

Synopsis
--------

Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output






Parameters
----------

 params
   (
   Required: True,
   Type:     str
   )

   Description:
     The Websphere Application Server to be started.


 wasdir
   (
   Required: optional,
   Type:     path,
   Default:  /appl/was
   )

   Description:
     The rout path of the Websphere installation.


 nowait
   (
   Required: optional,
   Type:     bool,
   Default:  False
   )

   Description:
     Option to skill waiting on the start of the server to finish.





Notes
-----

.. note::
   - None.




Examples
--------

.. code-block:: yaml+jinja 

    
    # start a JVM in nowaited mode
    - name: Start the JVM <stc1xxx> nowait 
      startserver:
         params: "{{ servername }}"
         nowait: True
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
    # start a JVM in waited mode
    - name: Start the JVM <stc1xxx> waited
      startserver:
         params: "{{ servername }}"
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
      debug:
        msg: "{{ rc }}"
      



Return Values
-------------

rc 
  ( 
  Returned: always,
  Type:     int,
  Sample:   0
  )
Description:
  script return code.


stdout 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stdout by the script executed


stdout_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stdout by the script executed, converted into string array by \n delimiter


stderr 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stderr by the script executed


stderr_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stderr by the script executed, converted into string array by \n delimiter





Status
------




- This module is . *[wip]*


- This module is maintained by IBM/ABN-AMRO ansbile team.



Authors
~~~~~~~

- Joined IBM and ABN-AMRO infra ansible team

.. _stopserver_module:


stopserver -- Invoke the websphere stop server script (stopServer.sh)
=====================================================================

.. contents::
   :local:
   :depth: 1
   :backlinks: top

Synopsis
--------

Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output






Parameters
----------

 params
   (
   Required: True,
   Type:     str
   )

   Description:
     The Websphere Application Server to be started.


 wasdir
   (
   Required: optional,
   Type:     path,
   Default:  /appl/was
   )

   Description:
     The rout path of the Websphere installation.


 nowait
   (
   Required: optional,
   Type:     bool,
   Default:  False
   )

   Description:
     Option to skill waiting on the start of the server to finish.





Notes
-----

.. note::
   - None.




Examples
--------

.. code-block:: yaml+jinja 

    
    # stop a JVM in nowaited mode
    - name: Stop the JVM <stc1xxx> nowait 
      stopserver:
         params: "{{ servername }}"
         nowait: True
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
    # stop a JVM in waited mode
    - name: Stop the JVM <stc1xxx> waited
      stoserver:
         params: "{{ servername }}"
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
      debug:
        msg: "{{ rc }}"
      



Return Values
-------------

rc 
  ( 
  Returned: always,
  Type:     int,
  Sample:   0
  )
Description:
  script return code.


stdout 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stdout by the script executed


stdout_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stdout by the script executed, converted into string array by \n delimiter


stderr 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stderr by the script executed


stderr_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stderr by the script executed, converted into string array by \n delimiter





Status
------




- This module is . *[wip]*


- This module is maintained by IBM/ABN-AMRO ansbile team.



Authors
~~~~~~~

- Joined IBM and ABN-AMRO infra ansible team

.. _wsadmin_module:


wsadmin -- Invoke the websphere start server script (startServer.sh)
====================================================================

.. contents::
   :local:
   :depth: 1
   :backlinks: top

Synopsis
--------

Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output






Parameters
----------

 params
   (
   Required: False,
   Type:     str
   )

   Description:
     Random option to pass to the wsadmin.sh


 wasdir
   (
   Required: optional,
   Type:     path,
   Default:  /appl/was/profiles/dmgr
   )

   Description:
     The rout path of the Websphere installation.


 script_stdin
   (
   Required: optional,
   Type:     str
   )

   Description:
     String to be passed to the stdin of the executing wsadmin.sh


 script_file
   (
   Required: optional,
   Type:     path
   )

   Description:
     file that will be processed with the -f to the executing wsadmin.sh





Notes
-----

.. note::
   - None.




Examples
--------

.. code-block:: yaml+jinja 

    
    # only string as input
    - name: Passing string to wsadmin
      wsadmin:
         script_stdin: print 'Hello world, whats the meaning of life'
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo
    # only file as input
    - name: passing file to wsadmin
      wsadmin:
         script_file: /tmp/ansible/test
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo  
    # string and file as input
    - name: passing both a file and string to wsadmin
      wsadmin:
         script_stdin: print 'Hello world, whats the meaning of life'
         script_file: /tmp/ansible/test
      register: rc
      become: yes
      become_user: wasusr
      become_method: sudo  



Return Values
-------------

rc 
  ( 
  Returned: always,
  Type:     int,
  Sample:   0
  )
Description:
  script return code.


stdout 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  filtered output written to the stdout by the script executed. Message starting with one of these WASX7023E,WASX7213I,WASX8011W,WASX7031I are removed


stdout_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  filtered output written to the stdout by the script executed, converted into string array by \n delimiter


stderr 
  ( 
  Returned: always,
  Type:     str,
  Sample:   this ouput is multiline\nyou see
  )
Description:
  raw output written to the stderr by the script executed


stderr_lines 
  ( 
  Returned: always,
  Type:     str,
  Sample:   ['this ouput is multiline', 'you see']
  )
Description:
  raw output written to the stderr by the script executed, converted into string array by \n delimiter





Status
------




- This module is . *[wip]*


- This module is maintained by IBM/ABN-AMRO ansbile team.



Authors
~~~~~~~

- Joined IBM and ABN-AMRO infra ansible team

