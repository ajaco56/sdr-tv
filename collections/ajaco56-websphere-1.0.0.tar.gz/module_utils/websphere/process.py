from __future__ import (absolute_import, division, print_function)

__metaclass__ = type

DOCUMENTATION = r'''
'''

EXAMPLES = r'''
'''

RETURN = r'''
'''

import datetime
import platform
import subprocess
import os
import json
class ProcessShell:

    default_stdin_log = "No stdin"
    child = None
    stdout_value = None
    stderr_value = None
    remove_filter = None
    none_fatal_returncodes = [0]

    def __init__(self, processagruments, parameters=None, stdin=None, remove_filter=None, none_fatal_returncodes=None):
        self.processagruments = processagruments
        self.stdin = stdin
        self.parameters = parameters
        self.remove_filter = remove_filter
        if none_fatal_returncodes is not None:
            self.none_fatal_returncodes = none_fatal_returncodes

    def getstdinlog(self):
        if self.stdin is not None:
            return self.stdin
        else:
            return self.default_stdin_log

    def get_processagruments(self):
        return self.processagruments

    def get_stderr(self):
        return self.stderr_value

    def get_stdout(self):
        return self.stdout_value

    def get_returncode(self):
        if self.child is None:
            return self.child
        else:
            return self.child.returncode

    def execute(self):
        processagruments = self.processagruments
        if self.parameters is not None:
            processagruments += " " + self.parameters
        self.child = subprocess.Popen([processagruments], shell=True,
                                      stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        self.stdout_value, self.stderr_value = self.child.communicate(
            self.stdin)
        if self.child.returncode == 0 and self.remove_filter is not None:
            self.stdout_value = self.filter_str(self.stdout_value)
        return self.stdout_value, self.stderr_value

    def is_non_fatal_rc(self):
        if self.child is None:
            return False
        else:
            return self.child.returncode in self.none_fatal_returncodes

    def filter_str(self, in_string):
        import re
        has_filtered = ""
        matcher = re.compile(self.remove_filter)
        to_be_filtered = in_string.split('\n')
        for item in filter(matcher.match, to_be_filtered):
            has_filtered += item + "\n"
        return has_filtered

    def process_result(self, in_string):
        parse_result_return = {}
        parse_result_return['rc'] = self.get_returncode()
        return parse_result_return

    def to_json(self):
        to_json_obj = {}
        to_json_obj["rc"] = self.get_returncode()
        return to_json_obj

    def to_json_str(self):
        return json.dumps(self.to_json())


def main():
    instring1 = "WASX7023E: Error creating \"SOAP\" connection to host \"vm00003998.nl.eu.abnamro.com\"; exception information: com.ibm.websphere.management.exception.ConnectorNotAvailableException: [SOAPException: faultCode=SOAP-ENV:Client; msg=Unable to find a valid IP for host vm00003998.nl.eu.abnamro.com]\nWASX7213I: This scripting client is not connected to a server process; please refer to the log file /appl/was/profiles/dmgr/logs/wsadmin.traceout for additional information.\nWASX8011W: AdminTask object is not available.\nWASX7031I: For help, enter: \"print Help.help()\"\nwsadmin>Hello world, whats the meaning of life\nwsadmin>"
    test = ProcessShell(
        "", None, None, "^(?!(WASX7023E|WASX7213I|WASX8011W|WASX7031I)|\.).*").filter_str(instring1)
    print(test)


if __name__ == '__main__':
    main()
