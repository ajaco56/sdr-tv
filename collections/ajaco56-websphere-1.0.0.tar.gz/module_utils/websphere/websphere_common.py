from __future__ import (absolute_import, division, print_function)
from ansible.module_utils.websphere.process import ProcessShell
from ansible.module_utils.basic import *
__metaclass__ = type

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['wip'],
                    'supported_by': 'IBM/ABN-AMRO ansbile team'}
DOCUMENTATION = r'''
---
module: startserver
short_description: Invoke the websphere start server script (startServer.sh)
description:
- Provide a wrapper arround the (c) Websphere application shell scripts. The module execute the script and cleans up the output
options:
  params:
    description:
    - The Websphere Application Server to be started.
    type: str
    required: true
  wasdir:
    description:
    - The rout path of the Websphere installation.
    type: path
    default: /appl/was
  nowait:
    description:
    - Option to skill waiting on the start of the server to finish.
    type: bool
    default: False

notes:
-  None.

version_added: 0.0.1
author:
- Joined IBM and ABN-AMRO infra ansible team
'''

EXAMPLES = r'''
# start a JVM in nowaited mode
- name: Start the JVM <stc1xxx> nowait
  startserver:
     params: "{{ servername }}"
     nowait: True
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo
# start a JVM in waited mode
- name: Start the JVM <stc1xxx> waited
  startserver:
     params: "{{ servername }}"
  register: rc
  become: yes
  become_user: wasusr
  become_method: sudo
  debug:
    msg: "{{ rc }}"

'''

RETURN = r'''
rc:
  description: script return code.
  returned: always
  type: int
  sample: 0
stdout:
  description: raw output written to the stdout by the script executed
  returned: always
  type: str
  sample: this ouput is multiline\nyou see
stdout_lines:
  description: raw output written to the stdout by the script executed, converted into string array by \n delimiter
  returned: always
  type: str
  sample:
     - this ouput is multiline
     - you see
stderr:
  description: raw output written to the stderr by the script executed
  returned: always
  type: str
  sample: this ouput is multiline\nyou see
stderr_lines:
  description: raw output written to the stderr by the script executed, converted into string array by \n delimiter
  returned: always
  type: str
  sample:
     - this ouput is multiline
     - you see
'''


class StartServer(ProcessShell):
    remove_filter = ""
    none_fatal_rcs = [0, 255]

    def __init__(self, wasdir, params, nowait=None, timeout=None):
        if nowait is not None and nowait == True:
            params += " -nowait"
        if timeout is not None and timeout > 0:
            params += " -timeout " + str(timeout)
        processagruments = wasdir + '/bin/startServer.sh'
        super(StartServer, self).__init__(processagruments,
                                          parameters=params, none_fatal_returncodes=self.none_fatal_rcs)


class StopServer(ProcessShell):
    remove_filter = ""
    none_fatal_rcs = [0, 246]

    def __init__(self, wasdir, params, nowait=None, timeout=None):
        if nowait is not None and nowait == True:
            params += " -nowait"
        if timeout is not None and timeout > 0:
            params += " -timeout " + str(timeout)
        processagruments=wasdir + '/bin/stopServer.sh'
        super(StopServer, self).__init__(processagruments,
                                         parameters = params, none_fatal_returncodes = self.none_fatal_rcs)


class WSAdmin(ProcessShell):
    default_file_log="No script"
    remove_filter="^(?!(WASX7023E|WASX7213I|WASX8011W|WASX7031I|WASX7209I)|\.).*"
    infile=None

    def __init__(self, wasdir, params, script_stdin, script_file):
        processagruments=wasdir + '/bin/wsadmin.sh -lang jython'
        if script_file is not None:
            processagruments += ' -f ' + script_file
        super(WSAdmin, self).__init__(processagruments, parameters = params,
                                      stdin=script_stdin, remove_filter=self.remove_filter)
        self.infile = script_file

    def getfilelog(self):
        if self.infile is not None:
            return self.infile
        else:
            return self.default_file_log
