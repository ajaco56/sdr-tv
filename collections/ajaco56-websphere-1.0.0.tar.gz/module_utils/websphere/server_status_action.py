from __future__ import (absolute_import, division, print_function)
if __name__ == '__main__':
   from module_utils.websphere.process import ProcessShell
else:
   from ansible.module_utils.websphere.process import ProcessShell
    
import re
import json
import time
__metaclass__ = type

DOCUMENTATION = r'''
Filter ADMU0508I lines from the results and pars them
'''

EXAMPLES = r'''
'''

RETURN = r'''
'''


class ServerInfoData:
    state_starting = "STARTING"
    state_started = "STARTED"
    state_running = "RUNNING"
    state_stopping = "STOPPING"
    state_stopped = "STOPPED"
    state_unreachable = "UNREACHABLE"
    state_undefined = ""

    MATCH_STRING = "^ADMU050(.)I: The (.*) \"(.*)\" .*[s|t] (.*)$"
    server_type = None
    server_name = None
    server_state = None

    count = 0
    timestamp = time.time()
    server_monitor = None

    def __init__(self, wasdir, instring, desired_state):
        self.wasdir = wasdir
        self.desired_state = desired_state
        self.parse(instring)
        self.server_monitor = ServerAction(
            wasdir, parameters=self.get_server_name(), requested_state=desired_state)

    def parse(self, input_str=None):
        matcher = re.compile(self.MATCH_STRING)
        groups = matcher.match(input_str).groups()
        if groups is not None:
            self.server_type = groups[1]
            self.server_name = groups[2]
            if groups[0] == "8":
                self.server_state = groups[3]
            else:
                self.server_state = self.state_unreachable

    def is_started(self):
        if self.server_state == self.state_started or self.server_state == self.state_running:
            return True
        return False

    def is_stopped(self):
        if self.server_state == self.state_stopped:
            return True
        return False

    def is_starting(self):
        if self.server_state == self.state_starting:
            return True
        return False

    def is_stopping(self):
        if self.server_state == self.state_stopping:
            return True
        return False

    def is_unreachable(self):
        if self.server_state == self.state_unreachable:
            return True
        return False

    def is_stable_state(self):
        if self.is_started() or self.is_stopped:
            return True
        else:
            return False

    def get_server_name(self):
        return self.server_name

    def get_server_state(self):
        return self.server_state

    def get_count(self):
        return self.count

    def do_monitor(self):
        if self.server_monitor is not None:
            self.server_monitor.execute()
            if self.server_monitor.is_non_fatal_rc():
                self.parse(self.server_monitor.get_stdout())
            self.count += 1
        return self

    def get_monitor(self):
        return self.server_monitor

    def to_json(self):
        to_json_obj = {"state": self.server_state, "desired": {
            "state": self.desired_state, "count": self.count, "timestamp": self.timestamp, "correct_state": self.is_in_requested_state()}}
        return to_json_obj

    def to_json_str(self):
        return json.dumps(self.to_json())



class ServerStatus(ProcessShell):
    remove_filter = "ADMU050[8|9]I:(.*)$"
    parsresult = {}

    def __init__(self, wasdir, params):
        processagruments = wasdir + '/bin/serverStatus.sh'
        super(ServerStatus, self).__init__(processagruments, params,
                                           remove_filter=self.remove_filter)

    def process_result(self, in_string=None):
        parse_result_return = {}

        if in_string is not None:
            instring = in_string
        else:
            instring = self.stdout_value
        MATCH_STRING = "ADMU050[8|9]I:(.*)$"

        self.parsresult = {ServerInfo.WEB_SERVER_TYPE: [],
                           ServerInfo.APPL_SERVER_TYPE: [],
                           ServerInfo.NODE_AGENT_TYPE: []}
        matcher = re.compile(MATCH_STRING)
        converted_instring = instring.split('\n')
        for item in filter(matcher.match, converted_instring):
            server_status = ServerInfoData(
                self.wasdir, item, self.requested_state)
            parse_result_return[server_status.get_server_type()].append(
                server_status)
        return parse_result_return

    def to_json(self):

        to_json_obj = {}
        if self.parsresult is not None:

            for server_type in self.get_server_types():
                to_json_obj[server_type] = {}
                for server in self.get_servers(server_type):
                    to_json_obj[server_type][server.get_server_name()
                                             ] = server.to_json()
        return to_json_obj

    def to_json_str(self):
        return json.dumps(self.to_json())

    def get_server_types(self):
        results = []
        for server_type in self.parsresult:
            results.append(server_type)
        return results

    def get_servers(self, server_type):
        results = []
        for server in self.parsresult[server_type]:
            results.append(server)
        return results


def main():
    instring1 = "ADMU0116I: Tool information is being logged in file\n           /appl/was/profiles/node/logs/serverStatus.log\nADMU0128I: Starting tool with the node profile\nADMU0503I: Retrieving server status for all servers\nADMU0505I: Servers found in configuration:\nADMU0506I: Server name: sth1bve\nADMU0506I: Server name: stc1bve\nADMU0506I: Server name: nodeagent\nADMU0508I: The Web server \"sth1bve\" is STOPPED\nADMU0509I: The Application Server \"stc1bve\" cannot be reached. It appears to be\n           stopped.\nADMU0509I: The Node Agent \"nodeagent\" cannot be reached. It appears to be\n           stopped.\n"
    instring2 = "ADMU0116I: Tool information is being logged in file\n           /appl/was/profiles/node/logs/serverStatus.log\nADMU0128I: Starting tool with the node profile\nADMU0503I: Retrieving server status for all servers\nADMU0505I: Servers found in configuration:\nADMU0506I: Server name: eth5isd\nADMU0506I: Server name: etc4isd\nADMU0506I: Server name: etc5isd\nADMU0506I: Server name: nodeagent\nADMU0506I: Server name: eth4isd\nADMU0506I: Server name: eth1isd\nADMU0506I: Server name: eth3isd\nADMU0506I: Server name: etc2isd\nADMU0506I: Server name: etc6isd\nADMU0506I: Server name: eth6isd\nADMU0506I: Server name: etc1isd\nADMU0506I: Server name: eth2isd\nADMU0506I: Server name: etc3isd\nADMU0508I: The Web server \"eth5isd\" is RUNNING\nADMU0508I: The Application Server \"etc4isd\" is STARTED\nADMU0508I: The Application Server \"etc5isd\" is STARTED\nADMU0508I: The Node Agent \"nodeagent\" is STARTED\nADMU0508I: The Web server \"eth4isd\" is RUNNING\nADMU0508I: The Web server \"eth1isd\" is RUNNING\nADMU0508I: The Web server \"eth3isd\" is RUNNING\nADMU0508I: The Application Server \"etc2isd\" is STARTED\nADMU0508I: The Application Server \"etc6isd\" is STARTED\nADMU0508I: The Web server \"eth6isd\" is RUNNING\nADMU0508I: The Application Server \"etc1isd\" is STARTED\nADMU0508I: The Web server \"eth2isd\" is RUNNING\nADMU0508I: The Application Server \"etc3isd\" is STARTED\n"
    extr = ServerStatus(None, None, None)
    extr.process_result(instring1)
    test = extr.to_json()
    print(test)
    test = extr.get_server_types()
    print(test)
    for servertype in test:
        for server in extr.get_servers(servertype):
            print(server.get_server_name())
    extr = ServerStatus(None, None, None)
    extr.process_result(instring2)
    test = extr.to_json()
    print(test)


if __name__ == '__main__':
    main()
