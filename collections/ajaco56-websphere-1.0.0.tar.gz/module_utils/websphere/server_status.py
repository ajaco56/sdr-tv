from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = r'''
Filter ADMU0508I lines from the results and pars them
'''

EXAMPLES = r'''
'''

RETURN = r'''
'''
if __name__ == '__main__':
    from process import ProcessShell
else:
    from ansible.module_utils.websphere.process import ProcessShell

import re
import json
import time
__metaclass__ = type


class ServerInfoData:
    STATE_STARTING = "STARTING"
    STATE_STARTED = "STARTED"
    STATE_RUNNING = "RUNNING"
    STATE_STOPPING = "STOPPING"
    STATE_STOPPED = "STOPPED"
    STATE_UNREACHABLE = "UNREACHABLE"
    state_undefined = ""

    WEB_SERVER_TYPE = "Web server"
    APPL_SERVER_TYPE = "Application Server"
    NODE_AGENT_TYPE = "Node Agent"

    MATCH_STRING = "^ADMU050(.)I: The (.*) \"(.*)\" .*[s|t] (.*)$"

    server_type = None
    server_name = None
    server_state = None

    def __init__(self, instring):
        self.parse(instring)

    def parse(self, input_str=None):
        matcher = re.compile(self.MATCH_STRING)
        groups = matcher.match(input_str).groups()
        if groups is not None:
            self.server_type = groups[1]
            self.server_name = groups[2]
            if groups[0] == "8":
                self.server_state = groups[3]
            else:
                self.server_state = ServerInfoData.STATE_UNREACHABLE

    def is_started(self):
        if self.server_state == ServerInfoData.STATE_STARTED or ServerInfoData.server_state == self.STATE_RUNNING:
            return True
        return False

    def is_stopped(self):
        if self.server_state == ServerInfoData.STATE_STOPPED:
            return True
        return False

    def is_starting(self):
        if self.server_state == ServerInfoData.STATE_STARTING:
            return True
        return False

    def is_stopping(self):
        if self.server_state == ServerInfoData.STATE_STOPPING:
            return True
        return False

    def is_unreachable(self):
        if self.server_state == ServerInfoData.STATE_UNREACHABLE:
            return True
        return False

    def is_stable_state(self):
        if self.is_started() or self.is_stopped:
            return True
        else:
            return False

    def get_server_name(self):
        return self.server_name

    def get_server_state(self):
        return self.server_state

    def get_server_type(self):
        return self.server_type

    def to_json(self):
        to_json_obj = {"state": self.server_state}
        return to_json_obj

    def to_json_str(self):
        return json.dumps(self.to_json())


class ServerStatus(ProcessShell):
    remove_filter = "ADMU050[8|9]I:(.*)$"
    parsresult = {}

    def __init__(self, wasdir, params):
        processagruments = wasdir + '/bin/serverStatus.sh'
        super(ServerStatus, self).__init__(processagruments, params,
                                           remove_filter=self.remove_filter)

    def process_result(self, in_string=None):
        parse_result_return = {}

        if in_string is not None:
            instring = in_string
        else:
            instring = self.stdout_value
        MATCH_STRING = "ADMU050[8|9]I:(.*)$"

        parse_result_return = {ServerInfoData.WEB_SERVER_TYPE: [],
                               ServerInfoData.APPL_SERVER_TYPE: [],
                               ServerInfoData.NODE_AGENT_TYPE: []}

        matcher = re.compile(MATCH_STRING)
        converted_instring = instring.split('\n')
        for item in filter(matcher.match, converted_instring):
            server_status = ServerInfoData(
                item)
            parse_result_return[server_status.get_server_type()].append(
                server_status)
        self.parsresult = parse_result_return
        return parse_result_return

    def to_json(self):
        to_json_obj = {}
        if self.parsresult is not None:
            for server_type in self.get_server_types():
                to_json_obj[server_type] = {}
                for server in self.get_servers(server_type):
                    to_json_obj[server_type][server.get_server_name()
                                             ] = server.to_json()
        to_json_obj["rc"] =self.get_returncode()
        return to_json_obj

    def to_json_str(self):
        return json.dumps(self.to_json())

    def get_server_types(self):
        results = []
        for server_type in self.parsresult:
            results.append(server_type)
        return results

    def get_servers(self, server_type):
        results = []
        for server in self.parsresult[server_type]:
            results.append(server)
        return results


def main():
    instring1 = "ADMU0116I: Tool information is being logged in file\n           /appl/was/profiles/node/logs/serverStatus.log\nADMU0128I: Starting tool with the node profile\nADMU0503I: Retrieving server status for all servers\nADMU0505I: Servers found in configuration:\nADMU0506I: Server name: sth1bve\nADMU0506I: Server name: stc1bve\nADMU0506I: Server name: nodeagent\nADMU0508I: The Web server \"sth1bve\" is STOPPED\nADMU0509I: The Application Server \"stc1bve\" cannot be reached. It appears to be\n           stopped.\nADMU0509I: The Node Agent \"nodeagent\" cannot be reached. It appears to be\n           stopped.\n"
    instring2 = "ADMU0116I: Tool information is being logged in file\n           /appl/was/profiles/node/logs/serverStatus.log\nADMU0128I: Starting tool with the node profile\nADMU0503I: Retrieving server status for all servers\nADMU0505I: Servers found in configuration:\nADMU0506I: Server name: eth5isd\nADMU0506I: Server name: etc4isd\nADMU0506I: Server name: etc5isd\nADMU0506I: Server name: nodeagent\nADMU0506I: Server name: eth4isd\nADMU0506I: Server name: eth1isd\nADMU0506I: Server name: eth3isd\nADMU0506I: Server name: etc2isd\nADMU0506I: Server name: etc6isd\nADMU0506I: Server name: eth6isd\nADMU0506I: Server name: etc1isd\nADMU0506I: Server name: eth2isd\nADMU0506I: Server name: etc3isd\nADMU0508I: The Web server \"eth5isd\" is RUNNING\nADMU0508I: The Application Server \"etc4isd\" is STARTED\nADMU0508I: The Application Server \"etc5isd\" is STARTED\nADMU0508I: The Node Agent \"nodeagent\" is STARTED\nADMU0508I: The Web server \"eth4isd\" is RUNNING\nADMU0508I: The Web server \"eth1isd\" is RUNNING\nADMU0508I: The Web server \"eth3isd\" is RUNNING\nADMU0508I: The Application Server \"etc2isd\" is STARTED\nADMU0508I: The Application Server \"etc6isd\" is STARTED\nADMU0508I: The Web server \"eth6isd\" is RUNNING\nADMU0508I: The Application Server \"etc1isd\" is STARTED\nADMU0508I: The Web server \"eth2isd\" is RUNNING\nADMU0508I: The Application Server \"etc3isd\" is STARTED\n"
    extr = ServerStatus("", "")
    processed_results=extr.process_result(instring1)
    test = extr.to_json()
    print(test)
    test = extr.get_server_types()
    print(test)
    for servertype in test:
        for server in extr.get_servers(servertype):
            print(server.get_server_name())
    extr = ServerStatus("","")
    extr.process_result("")
    test = extr.to_json()
    print(test)


if __name__ == '__main__':
    main()
